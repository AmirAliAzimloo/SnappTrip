# 💚 Please read this before check code thanks 💚

I do this task with two diffrent method and in each method I write about that please read that description
And also I have 3 diffrent example for you that show these hooks can use in both controlled and uncontrolled
component as well as we want with best performance and according to DRY,S.O.L.I.D,Best Practice and another methods.  
I hope you will be satisfied 💚🌹.
